import 'package:raid/service/api.dart';

class BaseApi {
  Api api = Api();
}
