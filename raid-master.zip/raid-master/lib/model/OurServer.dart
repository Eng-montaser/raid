class OurServerData{
  int id;
  String name;
  String image;
  OurServerData({this.id,this.name,this.image});
}